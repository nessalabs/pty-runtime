#!/usr/bin/env python3
"""Exercise the actual packaged helper with independent PTY/control endpoints."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import select
import signal
import socket
import struct
import subprocess
import termios
import time

FRAME = struct.Struct('<4sHHQiiii')


class Session:
    def __init__(self, executable, command, grace=40):
        self.generation = time.monotonic_ns() & ((1 << 63) - 1)
        self.master, slave = os.openpty()
        attrs = termios.tcgetattr(slave)
        attrs[3] &= ~termios.ECHO
        termios.tcsetattr(slave, termios.TCSANOW, attrs)
        self.channels = []
        children = []
        for _ in range(2):
            parent, child = socket.socketpair()
            self.channels.append(parent)
            children.append(child)
        sources = [children[0].fileno(), children[1].fileno(), self.master, slave]
        copies = [fcntl.fcntl(fd, fcntl.F_DUPFD_CLOEXEC, 300) for fd in sources]

        def setup():
            for target, source in enumerate(copies, 3):
                os.dup2(source, target)

        self.process = subprocess.Popen(
            [str(executable), '--pty-runtime-guardian-v1', str(self.generation),
             str(grace), '/bin/sh', '-c', command],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, close_fds=False, preexec_fn=setup, env={})
        for fd in copies:
            os.close(fd)
        for child in children:
            child.close()
        os.close(slave)
        os.set_blocking(self.master, False)
        for channel in self.channels:
            channel.setblocking(False)
        self.pending = [bytearray(), bytearray()]
        self.closed = [False, False]
        self.frames = []
        self.output = bytearray()
        self.ids = None

    def pump(self, timeout=0.02):
        readable = [self.master]
        readable += [channel for index, channel in enumerate(self.channels) if not self.closed[index]]
        ready, _, _ = select.select(readable, [], [], timeout)
        for descriptor in ready:
            if descriptor == self.master:
                try:
                    self.output.extend(os.read(self.master, 65536))
                except OSError:
                    pass
                continue
            index = self.channels.index(descriptor)
            data = descriptor.recv(4096)
            if not data:
                self.closed[index] = True
                continue
            self.pending[index].extend(data)
            while len(self.pending[index]) >= FRAME.size:
                packet = bytes(self.pending[index][:FRAME.size])
                del self.pending[index][:FRAME.size]
                magic, version, kind, generation, *values = FRAME.unpack(packet)
                assert (magic, version, generation) == (b'PTGR', 1, self.generation)
                self.frames.append((index, kind, values))
                if kind == 2:
                    self.ids = values

    def wait(self, condition, timeout=5):
        deadline = time.monotonic() + timeout
        while not condition():
            if time.monotonic() >= deadline:
                raise TimeoutError({'frames': self.frames, 'closed': self.closed,
                                    'output': bytes(self.output[-200:]), 'sentinel': self.process.pid})
            self.pump()

    def admitted(self):
        self.wait(lambda: self.ids is not None and any(kind == 3 for _, kind, _ in self.frames))
        return self.ids

    def send(self, kind):
        packet = FRAME.pack(b'PTGR', 1, kind, self.generation, 0, 0, 0, 0)
        for channel in self.channels:
            try:
                channel.sendall(packet)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def finished(self):
        self.wait(lambda: all(self.closed) and self.process.poll() is not None)

    def close(self):
        self.send(14)
        for channel in self.channels:
            channel.close()
        self.closed = [True, True]
        self.wait(lambda: self.process.poll() is not None)
        os.close(self.master)


def smoke(executable):
    session = Session(executable, "printf ready; read x; printf accepted; exit 7")
    try:
        workload, guardian, sentinel, sid = session.admitted()
        assert len({workload, guardian, sentinel}) == 3 and sentinel == sid
        session.wait(lambda: session.output == b'ready')
        os.write(session.master, b'go\n')
        session.wait(lambda: any(kind == 4 for _, kind, _ in session.frames))
        exits = [values[0] for _, kind, values in session.frames if kind == 4]
        assert all(os.waitstatus_to_exitcode(status) == 7 for status in exits)
        session.send(12)
        session.finished()
        assert session.output == b'readyaccepted'
        assert not any(kind == 6 for _, kind, _ in session.frames)
        return {'case': 'actual_exit_literal_input', 'result': 'pass', 'actual_exit': 7}
    finally:
        session.close()


def failure(executable, mode):
    command = "exec /bin/sh -i -c 'set -m; trap \"\" HUP TERM; sleep 300 & printf ready; sleep 300'"
    session = Session(executable, command)
    try:
        workload, guardian, sentinel, sid = session.admitted()
        session.wait(lambda: b'ready' in session.output and os.tcgetpgrp(session.master) != workload)
        target = sentinel if mode == 'sentinel_kill' else guardian
        os.kill(target, signal.SIGABRT if mode == 'guardian_abort' else signal.SIGKILL)
        session.finished()
        assert any(kind == 6 for _, kind, _ in session.frames)
        if mode != 'sentinel_kill':
            assert not any(kind == 4 for _, kind, _ in session.frames)
        return {'case': mode, 'result': 'pass', 'sid': sid, 'workload': workload,
                'actual_exit_observed': any(kind == 4 for _, kind, _ in session.frames)}
    finally:
        session.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--helper', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(smoke(args.helper)), flush=True)
    for mode in ['sentinel_kill', 'guardian_kill', 'guardian_abort']:
        print(json.dumps(failure(args.helper, mode)), flush=True)


if __name__ == '__main__':
    main()
