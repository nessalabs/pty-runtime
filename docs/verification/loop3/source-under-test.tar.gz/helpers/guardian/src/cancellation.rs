//! Normal TERM/KILL targets the actual workload plus pinned root/foreground groups.
use crate::{anchor::{Anchor, State}, protocol::Kind, workload::Workload};
use std::time::{Duration, Instant};
pub struct Cancellation {
    sid: i32, guardian: i32, host: i32, generation: u64,
    anchors: Vec<Anchor>, requested: Option<Kind>, applied: Option<Kind>,
    term_at: Option<Instant>, grace: Duration, resample: bool,
    retry_at: Instant,
}
impl Cancellation {
    pub fn new(sid: i32, guardian: i32, host: i32, generation: u64, grace: Duration) -> Self {
        Self { sid, guardian, host, generation, anchors: Vec::with_capacity(2),
            requested: None, applied: None, term_at: None, grace, resample: false, retry_at: Instant::now() }
    }
    pub fn request(&mut self, kind: Kind) {
        if self.requested != Some(Kind::Kill) { self.requested = Some(kind); }
    }
    pub fn stop(&mut self) { self.request(Kind::Kill); self.resample = false; }
    pub fn tick(&mut self, workload: &Workload, now: Instant, cleaning: bool) -> bool {
        let mut failed = false;
        for anchor in &mut self.anchors {
            if anchor.tick().is_err() { failed = true; }
        }
        self.anchors.retain(|anchor| anchor.state != State::Finished);
        if self.term_at.is_some_and(|start| now.duration_since(start) >= self.grace) {
            self.request(Kind::Kill);
        }
        if self.requested != self.applied {
            if let Some(kind) = self.requested {
                if workload.signal(if kind == Kind::Kill { libc::SIGKILL } else { libc::SIGTERM }).is_err() { failed = true; }
                for anchor in &mut self.anchors { anchor.request(kind); }
                if kind == Kind::Terminate { self.term_at = Some(now); }
                self.resample = true;
                self.applied = Some(kind);
            }
        }
        if cleaning { self.resample = false; return failed; }
        if self.resample && now >= self.retry_at {
            // SAFETY: this only discovers a hint; the member anchor must verify
            // its actual session and current foreground before any signal.
            let foreground = unsafe { libc::tcgetpgrp(self.host) };
            if foreground < 0 { return true; }
            if foreground == self.sid || foreground == self.guardian { return true; }
            let targets = [(workload.pid(), false), (foreground, true)];
            for (group, foreground_only) in targets {
                if group <= 0 || self.anchors.iter().any(|anchor| anchor.group == group) { continue; }
                if self.anchors.len() == 2 { break; }
                match Anchor::start(group, self.sid, self.host, foreground_only, self.generation) {
                    Ok(mut anchor) => {
                        if let Some(kind) = self.requested { anchor.request(kind); }
                        self.anchors.push(anchor);
                    }
                    Err(_) => failed = true,
                }
            }
            // At KILL a fresh sample follows retirement of old anchors. Under
            // churn finite work continues instead of an unsafe numeric fallback.
            self.resample = self.requested == Some(Kind::Kill) && !workload.reaped();
            self.retry_at = now + Duration::from_millis(10);
        }
        failed
    }
    pub fn empty(&self) -> bool { self.anchors.is_empty() }
    pub fn pollfds(&self, out: &mut Vec<libc::pollfd>) {
        for anchor in &self.anchors { anchor.pollfds(out); }
    }
    pub fn delay(&self, now: Instant) -> i32 {
        if !self.anchors.is_empty() || self.resample { return 10; }
        self.term_at.filter(|_| self.requested != Some(Kind::Kill)).map_or(-1,
            |start| (start + self.grace).saturating_duration_since(now).as_millis().min(i32::MAX as u128) as i32)
    }
}
