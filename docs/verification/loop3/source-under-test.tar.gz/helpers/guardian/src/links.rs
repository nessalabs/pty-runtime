//! Bounded, nonblocking status delivery remains separate from child reaping.
use crate::{os, protocol::{Channel, Frame, Kind}};
use std::{io, os::unix::net::UnixStream};
pub struct Endpoint { channel: Channel, healthy: bool, sent: u16, pending: [Option<Frame>; 15] }
impl Endpoint {
    fn new(stream: UnixStream, generation: u64) -> io::Result<Self> {
        Ok(Self { channel: Channel::new(stream, generation)?, healthy: true, sent: 0, pending: [None; 15] })
    }
    pub fn send(&mut self, frame: Frame) {
        let bit = 1 << frame.kind as u16;
        if !self.healthy || self.sent & bit != 0 { return; }
        self.pending[frame.kind as usize] = Some(frame); self.sent |= bit;
    }
    fn receive(&mut self) -> [Option<Frame>; 8] {
        let mut messages = [None; 8];
        if !self.healthy { return messages; }
        for message in &mut messages {
            match self.channel.receive() {
                Ok(Some(frame)) => *message = Some(frame),
                Ok(None) => break,
                Err(_) => { self.healthy = false; break; }
            }
        }
        if self.channel.eof() { self.healthy = false; }
        messages
    }
    fn flush(&mut self) {
        if !self.healthy { return; }
        for pending in &mut self.pending {
            if let Some(frame) = *pending {
                if self.channel.enqueue(frame).is_err() { break; }
                *pending = None;
            }
        }
        if self.channel.flush().is_err() { self.healthy = false; }
    }
    fn pollfd(&self) -> libc::pollfd {
        libc::pollfd { fd: if self.healthy { self.channel.fd() } else { -1 },
            events: libc::POLLIN | if self.channel.wants_write() { libc::POLLOUT } else { 0 }, revents: 0 }
    }
    pub fn healthy(&self) -> bool { self.healthy }
    pub fn pending(&self) -> bool { self.healthy && (self.channel.wants_write() || self.pending.iter().any(Option::is_some)) }
    pub fn fd(&self) -> i32 { self.channel.fd() }
}
pub struct Links { pub owner: Endpoint, pub peer: Endpoint, generation: u64 }
impl Links {
    pub fn new(owner: UnixStream, peer: UnixStream, generation: u64) -> io::Result<Self> {
        Ok(Self { owner: Endpoint::new(owner, generation)?, peer: Endpoint::new(peer, generation)?, generation })
    }
    pub fn frame(&self, kind: Kind, values: [i32; 4]) -> Frame { Frame::new(kind, self.generation, values) }
    pub fn notify(&mut self, kind: Kind, values: [i32; 4]) {
        let frame = self.frame(kind, values); self.owner.send(frame); self.peer.send(frame);
    }
    pub fn fault(&mut self) { self.notify(Kind::Fault, [0; 4]); }
    pub fn inbox(&mut self) -> ([Option<Frame>; 8], [Option<Frame>; 8]) {
        (self.owner.receive(), self.peer.receive())
    }
    pub fn flush(&mut self) { self.owner.flush(); self.peer.flush(); }
    pub fn pollfds(&self) -> Vec<libc::pollfd> { vec![self.owner.pollfd(), self.peer.pollfd()] }
    pub fn pause(&mut self, extra: &[libc::pollfd], milliseconds: i32) {
        self.flush();
        let mut fds = self.pollfds(); fds.extend_from_slice(extra);
        if os::pause(&mut fds, milliseconds).is_err() { self.fault(); }
    }
}
